# RBTV+ PS5 Port 0.3.0 — TV interface + real service flow

**This replaces the earlier Playback Lab mock.** It is an initial cross-platform port of the Android TV app's service flow and TV-oriented match browser. The project is not yet an installable PS5 title; it runs the API adapter and HLS relay on your Windows PC, with EVO Player used as the native playback target when it can read the exported playlist.

## What this build implements

- Decodes the APK's Protocol Buffers envelopes and the `PBBodySignatureResp`, live match list, match detail, teams, leagues, streams and activation flags.
- Follows the APK-derived catalogue request chain: bootstrap `code=100`, MD5-prefixed live route, match detail bootstrap `102..107`, and the stream-detail request.
- Shows real results returned by the configured app APIs after the user explicitly approves the endpoints and presses **Connect**.
- Calls the service's activation status/verify endpoints. Stream resolution is blocked unless the service reports a free or activated entitlement; the port does not invent an entitlement.
- Resolves a selected stream and creates a local HTTP relay that carries the returned stream headers and rewrites ordinary HLS playlist resource URLs.
- Exports the selected stream as a one-channel M3U playlist for EVO's IPTV feature, avoiding the need for the installed EVO build to have a Nuvio browser provider.
- Has a redesigned 10-foot TV interface with the RBTV+ logo and sports backdrops extracted from the APK, broad live-event spotlight populated only from actual API responses, match cards, sport filters, search, match detail/stream selection, activation view, endpoint settings and spatial directional focus inspired by polished native PS5 media apps.

## Run on Windows

Requirements: Node.js 20 or newer. No npm install is needed; it uses Node's built-in modules.

1. Extract this folder to your PC.
2. Run PowerShell from this folder:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\serve.ps1
   ```

3. Open the LAN URL shown in the console (prefer the `192.168.x.x` address if shown), for example `http://192.168.11.118:4173`.
4. Review the endpoint domains on the connection banner or under Settings. Tick the acknowledgement and press **Connect** only if you trust the APK/service source.
5. Select a sport and load matches, then open a match and choose a stream. The port checks activation status before resolving.

All service calls happen only after a deliberate button press. Do not expose port 4173 to the public internet. The API hosts embedded in this APK are unusual domains and may be stale; the settings view lets you change them, but the port does not verify ownership of these hosts.

## Send the selected stream to EVO Player

After a stream resolves, the bottom dock shows **Copy EVO playlist URL**. It should copy the machine's preferred LAN address, not `127.0.0.1`. On PS5, open EVO Player's Live TV / IPTV playlist input and add that URL. It returns a one-channel M3U containing the resolved stream's local relay URL. The PC and PS5 must stay on the same trusted LAN, and this server must remain running during playback.

If you opened the port at `http://127.0.0.1:4173`, do not manually copy that loopback address into EVO; the Copy button is designed to generate the LAN URL.

## Current limitations (important)

- The original `PPNetInterceptor` uses dynamic P2P/CSL/HLS configuration from remote app parameters. This version does **not** reproduce the original P2P engine or all HLS modifications. Some streams may fail, particularly if a provider requires special request headers, a proprietary P2P transport, a dynamic signature, or DRM. It deliberately does not bypass DRM or activation.
- The relay only handles normal HTTP(S) HLS playlists and their referenced resources; it has size bounds and rejects local/private target addresses. It is a prototype, not hardened for public hosting.
- The exact endpoints embedded in the uploaded APK can stop working or change. No real service endpoint was contacted during build/tests, so live service compatibility still requires a user-initiated test on your PC.
- The port now uses original RBTV+ branding and several sports backdrops from the APK, plus an adapted TV-first design language: focus glow, large team cards, a selected-event spotlight, and an expanded match-detail/stream-selector experience. The app API response is still the sole source of match names, logos, scores, times and stream rows; the port does not synthesize sample fixtures. It does not reproduce the original native Android layouts, ads or analytics wholesale.
- It does not build a new ELF/PKG or patch your EVO installation. Native EVO integration and on-console validation are separate work. The M3U export is the first bridge that can be tested without a special Nuvio provider.

## Test

```powershell
node --test .\tests\*.test.mjs
```

Tests use synthetic protobuf messages and mocked HTTPS responses only. They do not call the RBTV service.


## 0.3.0 interface changes

- Reworked the UI for couch distance: left navigation, poster-like sports shelves, a data-driven live-event spotlight, large-team cards, and clearer stream-selection rows.
- Added original RBTV+ logo/sports artwork extracted from the user-provided APK.
- Improved directional focus navigation to choose nearby controls spatially for a TV remote/DualSense-style input.
- Kept the real API catalogue/resolver flow. No placeholder fixture data is inserted; if the API is empty or unreachable the UI says so.
- This remains a Windows-hosted prototype with EVO M3U export, not a native PS5 installable application.
