const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = {
  config: null, sportType: 1, language: 0, matches: [], currentMatch: null,
  currentDetail: null, streamResolved: null, connected: false, activation: null,
  userInfo: null, view: 'matches', query: '', busy: false, lanBase: location.origin
};

function showToast(message, type = 'info', duration = 5000) {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast show${type === 'error' ? ' error' : type === 'success' ? ' success' : ''}`;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { el.className = 'toast'; }, duration);
}
function setBusy(on, text = 'Working…') {
  state.busy = on;
  $('#busyText').textContent = text;
  $('#busyOverlay').classList.toggle('hidden', !on);
  $$('.button').forEach(btn => { if (!btn.dataset.allowBusy) btn.disabled = on || (btn.id === 'connectButton' && !$('#serviceConsent').checked); });
}
async function apiFetch(path, options = {}) {
  const response = await fetch(path, { ...options, headers: { ...(options.body ? { 'content-type': 'application/json' } : {}), ...(options.headers || {}) } });
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text || 'Unexpected response' }; }
  if (!response.ok) {
    const error = new Error(data.error || `HTTP ${response.status}`);
    error.status = response.status; error.code = data.code; error.activation = data.activation;
    throw error;
  }
  return data;
}
function post(path, body) { return apiFetch(path, { method: 'POST', body: JSON.stringify(body) }); }
function setConnectionStatus(text, good = false, bad = false) {
  const pill = $('#connectionPill');
  pill.textContent = text;
  pill.className = `pill ${good ? 'pill-good' : bad ? 'pill-bad' : 'pill-muted'}`;
  $('#sideStatus').textContent = text;
  $('.status-dot').style.background = good ? 'var(--green)' : bad ? 'var(--red)' : 'var(--subtle)';
}
function timestampLabel(value) {
  const n = Number(value);
  if (!n) return 'Time TBC';
  const d = new Date(n > 1000000000000 ? n : n * 1000);
  if (Number.isNaN(d.getTime())) return 'Time TBC';
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function logoUrl(raw) {
  if (!raw) return '';
  try {
    const u = new URL(raw, state.config?.logoHost || location.origin);
    if (!['http:', 'https:'].includes(u.protocol)) return '';
    return u.href;
  } catch { return ''; }
}
function img(url, alt, classes) {
  const safe = logoUrl(url);
  return safe ? `<img class="${classes}" src="${esc(safe)}" alt="${esc(alt)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.hidden=true">` : `<div class="${classes}" aria-hidden="true"></div>`;
}
function matchNames(m) {
  return {
    home: m.home?.name || 'Home team', away: m.away?.name || 'Away team',
    league: m.league?.name || m.name || 'Live event'
  };
}
function filteredMatches() {
  const q = state.query.trim().toLocaleLowerCase();
  if (!q) return state.matches;
  return state.matches.filter(m => {
    const n = matchNames(m);
    return `${n.home} ${n.away} ${n.league} ${m.name}`.toLocaleLowerCase().includes(q);
  });
}
function renderMatches() {
  const grid = $('#matchesGrid');
  const matches = filteredMatches();
  $('#matchSubtitle').textContent = state.matches.length ? `${matches.length} of ${state.matches.length} events · ${sportLabel(state.sportType)}` : 'Connect and load the real catalogue.';
  if (!matches.length) {
    grid.innerHTML = `<div class="empty-state span-full"><div class="empty-orbit">RB<span>+</span></div><h3>${state.matches.length ? 'No matching events' : 'No events loaded'}</h3><p>${state.matches.length ? 'Try another team or league name.' : 'Connect to the APK service endpoints, then load live matches.'}</p><button class="button button-secondary focusable" id="loadMatchesEmpty">${state.matches.length ? 'Clear search' : 'Load live matches'}</button></div>`;
    $('#loadMatchesEmpty')?.addEventListener('click', () => state.matches.length ? (state.query = '', $('#searchInput').value = '', renderMatches()) : loadMatches());
    return;
  }
  const liveMatch = matches.find(m => m.status === 2 || m.status === 3);
  renderSpotlight(liveMatch || matches[0] || null, matches.length);
  grid.innerHTML = matches.map(m => {
    const n = matchNames(m); const streams = Array.isArray(m.streams) ? m.streams.length : 0;
    const isLive = m.status === 2 || m.status === 3;
    return `<article class="match-card focusable" tabindex="0" role="button" data-match-id="${m.id}" data-sport="${m.sportType || state.sportType}">
      <div class="match-meta"><div class="league-row">${img(m.league?.logo,'', 'league-logo')}<span class="league-name">${esc(n.league)}</span></div><span class="live-tag ${isLive ? 'live-now' : 'event-soon'}">${isLive ? '● LIVE NOW' : 'UPCOMING'}</span></div>
      <div class="teams"><div class="team">${img(m.home?.logo,n.home,'team-logo')}<span class="team-name">${esc(n.home)}</span></div><div class="score-col">${isLive ? `${Number(m.homeScore)||0} : ${Number(m.awayScore)||0}` : '<span class="versus">VS</span>'}</div><div class="team">${img(m.away?.logo,n.away,'team-logo')}<span class="team-name">${esc(n.away)}</span></div></div>
      <div class="match-footer"><span>${esc(timestampLabel(m.date))}</span><span class="stream-count">${streams ? `${streams} stream${streams === 1 ? '' : 's'}` : 'View match'} <b>→</b></span></div></article>`;
  }).join('');
  $$('.match-card', grid).forEach(card => {
    const activate = () => openMatch(Number(card.dataset.matchId), Number(card.dataset.sport));
    card.addEventListener('click', activate);
    card.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(); } });
  });
  applyFocus();
}
function renderSpotlight(match, visibleCount) {
  const el = $('#matchSpotlight');
  if (!el) return;
  if (!match) { el.hidden = true; el.innerHTML = ''; return; }
  const n = matchNames(match);
  const isLive = match.status === 2 || match.status === 3;
  const homeLogo = logoUrl(match.home?.logo), awayLogo = logoUrl(match.away?.logo);
  el.hidden = false;
  el.innerHTML = `<div class="spotlight-mark">${isLive ? 'LIVE' : 'RB+'}</div>
    <div class="spotlight-main"><div class="spotlight-kicker">${isLive ? '● Live now' : 'Featured fixture'} · ${esc(sportLabel(match.sportType || state.sportType))}</div>
    <h2 class="spotlight-title">${esc(n.league)}</h2><div class="spotlight-sub">${esc(timestampLabel(match.date))} · ${visibleCount} real ${visibleCount === 1 ? 'event' : 'events'} in this catalogue</div>
    <div class="spotlight-teams"><div class="spotlight-team">${homeLogo ? `<img src="${esc(homeLogo)}" alt="" loading="lazy">` : ''}<span>${esc(n.home)}</span></div><span class="spotlight-score">${isLive ? `${Number(match.homeScore)||0} : ${Number(match.awayScore)||0}` : 'VS'}</span><div class="spotlight-team">${awayLogo ? `<img src="${esc(awayLogo)}" alt="" loading="lazy">` : ''}<span>${esc(n.away)}</span></div></div></div>
    <button class="button button-primary spotlight-action focusable" type="button" id="spotlightOpen">${isLive ? 'Watch live' : 'View match'} →</button>`;
  $('#spotlightOpen')?.addEventListener('click', () => openMatch(Number(match.id), Number(match.sportType || state.sportType)));
}
function sportLabel(n) { return ({1:'Football',2:'Basketball',3:'Tennis',4:'Baseball',6:'Cricket',7:'Motorsport',8:'Rugby',9:'American Football',10:'Australian Rules',11:'Hockey',12:'Badminton',13:'Volleyball',14:'Combat Sports',15:'Cycling',16:'Handball',17:'Golf',18:'Darts',19:'Athletics',90:'Other'})[n] || `Sport ${n}`; }
function setView(name) {
  state.view = name;
  $$('.view').forEach(v => v.classList.remove('active-view'));
  $(`#view-${name}`)?.classList.add('active-view');
  $$('.rail-button').forEach(btn => { const active = btn.dataset.view === name || (name === 'detail' && btn.dataset.view === 'matches'); btn.classList.toggle('active', active); btn.classList.toggle('focused', btn.dataset.view === name); });
  $('#pageTitle').textContent = ({matches:'Live matches', detail:'Match details', activation:'Activation', settings:'Settings'})[name] || 'RBTV+';
  $('#refreshButton').classList.toggle('hidden', name === 'activation' || name === 'settings');
  applyFocus();
}
async function connectService() {
  if (!$('#serviceConsent').checked) return showToast('Tick the service-connection acknowledgement first.', 'error');
  setBusy(true, 'Connecting to the configured API hosts…');
  try {
    const payload = formConfig();
    const saved = await post('/api/config', payload);
    state.config = { ...state.config, ...saved.config };
    const result = await apiFetch('/api/connect');
    state.connected = true; state.userInfo = result.userInfo; state.activation = result.activation;
    $('#introBanner').classList.add('hidden');
    setConnectionStatus('API connected', true);
    renderActivation(result.activation);
    showToast(`Connected. Region reported: ${result.userInfo?.continent || 'unknown'} / ${result.userInfo?.country || 'unknown'}.`, 'success');
    await loadMatches();
  } catch (error) {
    state.connected = false;
    setConnectionStatus('Connection failed', false, true);
    showToast(`${error.message}. Check Settings for stale hosts or a changed server protocol.`, 'error', 9000);
  } finally { setBusy(false); }
}
function formConfig() {
  const obj = {};
  for (const k of ['dataApi','liveApi','logoHost','webOrigin','digit','language','userAgent']) {
    const el = $(`#${k}`); if (el) obj[k] = el.value.trim();
  }
  return obj;
}
async function loadMatches() {
  if (!state.connected && !$('#serviceConsent').checked) return showToast('Approve the service connection and press Connect first.', 'error');
  setBusy(true, `Loading ${sportLabel(state.sportType)}…`);
  try {
    if (!state.connected) {
      await post('/api/config', formConfig());
      const result = await apiFetch('/api/connect');
      state.connected = true; state.userInfo = result.userInfo; state.activation = result.activation;
      $('#introBanner').classList.add('hidden'); setConnectionStatus('API connected', true); renderActivation(result.activation);
    }
    const result = await apiFetch(`/api/matches?sportType=${state.sportType}&language=${state.language}`);
    state.matches = result.matches || [];
    renderMatches();
    showToast(`Loaded ${state.matches.length} events from the live API.`, 'success');
  } catch (error) {
    showToast(`${error.message}`, 'error', 9000);
    if (error.code === 'ACTIVATION_REQUIRED') { state.activation = error.activation; setView('activation'); renderActivation(error.activation); }
  } finally { setBusy(false); }
}
async function openMatch(matchId, sportType) {
  state.currentMatch = state.matches.find(m => Number(m.id) === matchId) || { id: matchId, sportType };
  state.currentDetail = null;
  setView('detail');
  $('#detailHeader').innerHTML = `<div class="empty-state"><div class="spinner"></div><h3>Loading match detail…</h3></div>`;
  $('#streamsList').innerHTML = '';
  try {
    const detail = await apiFetch(`/api/match/${matchId}?sportType=${sportType}&language=${state.language}`);
    state.currentDetail = detail;
    const match = detail.match || state.currentMatch;
    state.currentMatch = { ...state.currentMatch, ...match, streams: detail.streams || [] };
    renderMatchDetail();
  } catch (error) {
    const m = state.currentMatch; const n = matchNames(m);
    $('#detailHeader').innerHTML = `<h2>${esc(n.home)} vs ${esc(n.away)}</h2><p class="muted">Couldn't fetch detailed streams: ${esc(error.message)}</p>`;
    $('#streamsList').innerHTML = `<div class="empty-state"><h3>Detail request failed</h3><p>${esc(error.message)}</p><button id="retryDetail" class="button button-secondary focusable">Retry</button></div>`;
    $('#retryDetail')?.addEventListener('click', () => openMatch(matchId, sportType));
  }
}
function renderMatchDetail() {
  const m = state.currentMatch; const n = matchNames(m);
  $('#detailHeader').innerHTML = `<div class="league">${img(m.league?.logo,'','league-logo')} &nbsp; ${esc(n.league)} · ${esc(timestampLabel(m.date))}</div><div class="detail-teams"><div class="team">${img(m.home?.logo,n.home,'team-logo')}<span class="team-name">${esc(n.home)}</span></div><div class="detail-score">${m.status === 2 || m.status === 3 ? `${Number(m.homeScore)||0} : ${Number(m.awayScore)||0}` : 'VS'}<small>${esc(m.status === 2 || m.status === 3 ? 'LIVE' : 'Match')}</small></div><div class="team">${img(m.away?.logo,n.away,'team-logo')}<span class="team-name">${esc(n.away)}</span></div></div>`;
  const streams = m.streams || [];
  if (!streams.length) {
    $('#streamsList').innerHTML = `<div class="empty-state"><h3>No stream rows in match detail</h3><p>The app sometimes gets a stream list through the live catalogue. We'll expose those choices only when the API returns them; no stream endpoint or activation is bypassed.</p></div>`;
    return;
  }
  $('#streamsList').innerHTML = streams.slice().sort((a,b) => Number(b.recommended)-Number(a.recommended) || Number(b.priority)-Number(a.priority)).map(s => `<article class="stream-card"><div class="stream-icon">▷</div><div class="stream-info"><strong>${esc(s.fullName || s.name || `Stream ${s.id}`)}</strong><p>Stream ID ${s.id} · Site type ${s.siteType} · ${s.status ? 'status '+s.status : 'status not reported'}</p><div class="stream-badges">${s.recommended ? '<span class="mini-badge">Recommended</span>' : ''}${s.priority ? `<span class="mini-badge">Priority ${s.priority}</span>` : ''}${s.url ? '<span class="mini-badge">Embedded URL available</span>' : '<span class="mini-badge">Resolve URL on selection</span>'}</div></div><button class="button button-primary focusable resolve-stream" data-stream-id="${s.id}" data-site-type="${s.siteType}" type="button">Resolve stream →</button></article>`).join('');
  $$('.resolve-stream').forEach(btn => btn.addEventListener('click', () => resolveStream({
    matchId: m.id, sportType: m.sportType || state.sportType, streamId: Number(btn.dataset.streamId), siteType: Number(btn.dataset.siteType), title: `${n.home} vs ${n.away}`
  }, btn)));
  applyFocus();
}
async function resolveStream(req, button) {
  setBusy(true, 'Checking activation and resolving stream…');
  try {
    const result = await post('/api/resolve', req);
    state.streamResolved = result;
    $('#resolvedTitle').textContent = result.title || result.streamName;
    $('#resolvedSubtitle').textContent = `Resolved · ${result.headerCount} stream headers carried by local relay`;
    $('#playerDock').classList.remove('hidden');
    $('#copyM3uButton').dataset.url = `${state.lanBase}/api/current.m3u`;
    $('#copyRelayButton').dataset.url = result.relayUrl;
    $('#downloadM3uButton').href = '/api/current.m3u';
    showToast('Stream resolved. Copy the EVO playlist URL and add it under EVO Player → Live TV / IPTV.', 'success', 8000);
  } catch (error) {
    showToast(error.message, 'error', 9000);
    if (error.status === 403 || error.code === 'ACTIVATION_REQUIRED') {
      state.activation = error.activation || null; renderActivation(state.activation); setView('activation');
    }
  } finally { setBusy(false); }
}
function renderActivation(a) {
  const el = $('#activationStatusCard');
  if (!a) { el.className = 'activation-card'; el.innerHTML = `<span class="activation-icon">⌁</span><div><b>Not checked yet</b><p>Connect to check the service status.</p></div>`; return; }
  const positive = a.free || a.activated;
  el.className = `activation-card${positive ? ' good' : ''}`;
  const title = a.free ? 'Free access reported by service' : a.activated ? 'Activated' : a.error ? 'Status check failed' : 'Activation required';
  const detail = a.error || (a.expirationDate ? `Expires: ${timestampLabel(a.expirationDate)}` : a.message || (positive ? 'The service allows this installation.' : 'Enter a valid activation code issued by the provider.'));
  el.innerHTML = `<span class="activation-icon">${positive ? '✓' : '⌁'}</span><div><b>${esc(title)}</b><p>${esc(detail)}</p></div>`;
}
async function checkActivation() {
  setBusy(true, 'Checking activation status…');
  try { const a = await apiFetch('/api/activation/status'); state.activation = a; renderActivation(a); showToast(a.free || a.activated ? 'Service reports an active entitlement.' : 'Service reports activation is required.', a.free || a.activated ? 'success' : 'info'); }
  catch (error) { renderActivation({ error: error.message }); showToast(error.message, 'error'); }
  finally { setBusy(false); }
}
async function verifyActivation(event) {
  event.preventDefault();
  const code = $('#activationCode').value.trim();
  if (!code) return;
  setBusy(true, 'Verifying activation code with the service…');
  try {
    const result = await post('/api/activation/verify', { activationCode: code });
    state.activation = result.activation; renderActivation(result.activation);
    if (!result.activation.free && !result.activation.activated) throw new Error(result.message || 'The service did not mark this installation as activated.');
    $('#activationCode').value = '';
    showToast('Activation accepted by the service.', 'success');
  } catch (error) { showToast(error.message, 'error', 9000); }
  finally { setBusy(false); }
}
async function saveSettings(event) {
  event.preventDefault(); setBusy(true, 'Saving endpoint settings…');
  try {
    const result = await post('/api/config', formConfig()); state.config = { ...state.config, ...result.config }; state.language = Number(state.config.language || 0);
    showToast('Settings saved. No service call has been made by saving settings alone.', 'success');
  } catch (error) { showToast(error.message, 'error'); }
  finally { setBusy(false); }
}
async function copyElementData(button) {
  const value = button.dataset.url || $('#deviceId').textContent;
  try { await navigator.clipboard.writeText(value); showToast('Copied to clipboard.', 'success'); }
  catch { const t = document.createElement('textarea'); t.value = value; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); showToast('Copied to clipboard.', 'success'); }
}
async function init() {
  try {
    const c = await apiFetch('/api/config');
    state.config = c; state.sportType = Number(c.sportType || 1); state.language = Number(c.language || 0); state.lanBase = ['127.0.0.1','localhost','::1'].includes(location.hostname) ? `http://${c.network?.preferred || '127.0.0.1'}:${c.listenPort || 4173}` : location.origin;
    $('#deviceId').textContent = c.deviceId || 'not available';
    for (const key of ['dataApi','liveApi','logoHost','webOrigin','digit','language','userAgent']) if ($(`#${key}`)) $(`#${key}`).value = c[key] ?? '';
    setConnectionStatus('Not connected');
    $('#serviceConsent').checked = false;
    $('#connectButton').disabled = true;
  } catch (error) { showToast(`Local server config unavailable: ${error.message}`, 'error'); }
  applyFocus();
}
function applyFocus() {
  const visibleView = $('.view.active-view');
  if (!visibleView) return;
  $$('.focusable', visibleView).forEach((el, i) => {
    if (!el.hasAttribute('tabindex') && !['BUTTON','INPUT','A'].includes(el.tagName)) el.tabIndex = 0;
  });
  if (!visibleView.querySelector('.focusable.focused')) visibleView.querySelector('.focusable:not(:disabled)')?.classList.add('focused');
}
function moveFocus(direction) {
  const visible = $('.view.active-view');
  const items = $$('.focusable', visible).filter(el => !el.disabled && el.offsetParent !== null);
  if (!items.length) return;
  const current = document.activeElement?.classList?.contains('focusable') ? document.activeElement : visible.querySelector('.focusable.focused');
  if (!current) { focusElement(items[0]); return; }
  const cr = current.getBoundingClientRect();
  const horizontal = direction === 'left' || direction === 'right';
  let best = null, bestScore = Infinity;
  for (const candidate of items) {
    if (candidate === current) continue;
    const r = candidate.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const ox = cr.left + cr.width / 2, oy = cr.top + cr.height / 2;
    const primary = horizontal ? cx - ox : cy - oy;
    if ((direction === 'left' && primary >= -2) || (direction === 'right' && primary <= 2) || (direction === 'up' && primary >= -2) || (direction === 'down' && primary <= 2)) continue;
    const secondary = horizontal ? Math.abs(cy - oy) : Math.abs(cx - ox);
    const score = Math.abs(primary) + secondary * 1.8 + (secondary > (horizontal ? cr.height : cr.width) ? 80 : 0);
    if (score < bestScore) { best = candidate; bestScore = score; }
  }
  if (!best) {
    const idx = items.indexOf(current);
    const delta = direction === 'left' || direction === 'up' ? -1 : 1;
    best = items[(idx + delta + items.length) % items.length];
  }
  focusElement(best);
}
function focusElement(target) {
  const visible = $('.view.active-view');
  $$('.focusable', visible).forEach(el => el.classList.toggle('focused', el === target));
  target.focus({preventScroll:true});
  target.scrollIntoView({block:'nearest', inline:'nearest', behavior:'smooth'});
}

$$('.rail-button').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));
$$('.sport-chip').forEach(button => button.addEventListener('click', () => {
  $$('.sport-chip').forEach(b => b.classList.toggle('active', b === button));
  state.sportType = Number(button.dataset.sport); if (state.connected) loadMatches(); else showToast(`Selected ${sportLabel(state.sportType)}. Connect to load its live catalogue.`);
}));
$('#serviceConsent').addEventListener('change', () => { $('#connectButton').disabled = !$('#serviceConsent').checked || state.busy; });
$('#connectButton').addEventListener('click', connectService);
$('#refreshButton').addEventListener('click', () => state.view === 'detail' && state.currentMatch ? openMatch(state.currentMatch.id, state.currentMatch.sportType || state.sportType) : loadMatches());
$('#loadMatchesEmpty')?.addEventListener('click', loadMatches);
$('#backToMatches').addEventListener('click', () => setView('matches'));
$('#searchInput').addEventListener('input', e => { state.query = e.target.value; renderMatches(); });
$('#configForm').addEventListener('submit', saveSettings);
$('#activationForm').addEventListener('submit', verifyActivation);
$('#checkActivation').addEventListener('click', checkActivation);
$('#copyDeviceId').addEventListener('click', copyElementData);
$('#copyM3uButton').addEventListener('click', copyElementData);
$('#copyRelayButton').addEventListener('click', copyElementData);
document.addEventListener('keydown', event => {
  if (['ArrowDown','ArrowRight','ArrowUp','ArrowLeft'].includes(event.key)) { if (!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) { event.preventDefault(); moveFocus(({ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down'})[event.key]); } }
  else if ((event.key === 'Escape' || event.key === 'Backspace') && state.view === 'detail') { event.preventDefault(); setView('matches'); }
  else if ((event.key === 'Enter' || event.key === ' ') && document.activeElement?.classList?.contains('focusable') && document.activeElement.matches('article.match-card')) { event.preventDefault(); document.activeElement.click(); }
});
init();
