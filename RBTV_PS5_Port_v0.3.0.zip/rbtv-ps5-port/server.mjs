import http from 'node:http';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { RbtvApi } from './lib/rbtv-api.mjs';
import { parseActivationEnvelope } from './lib/protobuf.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const WEB = path.join(ROOT, 'webui');
const DATA = path.join(ROOT, 'data');
const port = Number(process.env.PORT || 4173);
const PORT_VERSION = '0.3.0';
const CONFIG_FILE = path.join(ROOT, 'config.json');
const DEVICE_FILE = path.join(DATA, 'device-id.txt');
fs.mkdirSync(DATA, { recursive: true });

const defaults = {
  dataApi: 'https://apis-data10.tcllu137fien.ru',
  liveApi: 'https://apis-live.ta2mnt200stayr2.cfd',
  logoHost: 'https://logos1.tcllu137fien.ru',
  webOrigin: 'https://www.rbtv77.com',
  digit: 'snd', language: 0, sportType: 1,
  userAgent: 'RBTV-PS5-Port/0.3 (compatibility client; user initiated)',
  networkTimeoutMs: 12000, maxResponseBytes: 20 * 1024 * 1024,
  activationRequired: true
};
let config = readConfig();
function readConfig() {
  try { return { ...defaults, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) }; }
  catch { return { ...defaults }; }
}
function saveConfig(next) {
  const safe = { ...config };
  for (const key of ['dataApi', 'liveApi', 'logoHost', 'webOrigin']) {
    if (next[key] !== undefined) {
      const u = new URL(String(next[key]));
      if (u.protocol !== 'https:' || u.username || u.password) throw new Error(`${key} must be a public HTTPS URL without embedded credentials`);
      safe[key] = u.origin;
    }
  }
  if (next.digit !== undefined) safe.digit = String(next.digit).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 16) || defaults.digit;
  if (next.language !== undefined) safe.language = Number.isInteger(Number(next.language)) ? Number(next.language) : defaults.language;
  if (next.sportType !== undefined) safe.sportType = Number.isInteger(Number(next.sportType)) ? Number(next.sportType) : defaults.sportType;
  if (next.userAgent !== undefined) safe.userAgent = String(next.userAgent).slice(0, 240);
  config = safe;
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2) + '\n', 'utf8');
  api.config = config;
}
if (!fs.existsSync(CONFIG_FILE)) fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2) + '\n', 'utf8');
if (!fs.existsSync(DEVICE_FILE)) fs.writeFileSync(DEVICE_FILE, `rbtv-ps5-${crypto.randomUUID()}\n`, 'utf8');
const deviceId = fs.readFileSync(DEVICE_FILE, 'utf8').trim();
let api = new RbtvApi(config);
const relayTokens = new Map();
let lastResolved = null;

function json(res, status, obj) {
  const body = Buffer.from(JSON.stringify(obj, null, 2));
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': body.length, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  res.end(body);
}
function text(res, status, value, type = 'text/plain; charset=utf-8') {
  const body = Buffer.from(value);
  res.writeHead(status, { 'content-type': type, 'content-length': body.length, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  res.end(body);
}
async function readBody(req, limit = 64 * 1024) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > limit) throw new Error('Request body too large');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}
function statFields(envelope) {
  try { return parseActivationEnvelope(envelope); }
  catch (error) { return { free: false, activated: false, decodeError: error.message }; }
}
async function activationStatus() {
  const result = await api.getActivationStatus(deviceId);
  const activation = statFields(result.envelope);
  return { ...activation, code: result.envelope.code, message: result.envelope.message };
}
async function requireActivation() {
  const status = await activationStatus();
  if (!status.free && !status.activated) {
    const error = new Error('Activation is required before resolving a stream. Enter a valid activation code from the app provider.');
    error.statusCode = 403;
    error.code = 'ACTIVATION_REQUIRED';
    error.activation = status;
    throw error;
  }
  return status;
}
function sportLabel(n) {
  return ({1:'Football',2:'Basketball',3:'Tennis',4:'Baseball',6:'Cricket',7:'Motorsport',8:'Rugby',9:'American Football',10:'Australian Rules',11:'Hockey',12:'Badminton',13:'Volleyball',14:'Combat Sports',15:'Cycling',16:'Handball',17:'Golf',18:'Darts',19:'Athletics',90:'Other'})[n] ?? `Sport ${n}`;
}
function privateIpV4(ip) {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return false;
  return p[0] === 10 || p[0] === 127 || (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) || (p[0] === 192 && p[1] === 168) || p[0] === 0 || p[0] >= 224;
}
function safeRemoteUrl(raw) {
  const u = new URL(raw);
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) throw new Error('Stream URL must be HTTP(S) without embedded credentials');
  const host = u.hostname.toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host === '::1' || privateIpV4(host)) throw new Error('Refusing a stream URL that points to a local/private address');
  return u;
}
function createRelay(sourceUrl, headers = {}, title = '') {
  const u = safeRemoteUrl(sourceUrl);
  const token = crypto.randomBytes(18).toString('base64url');
  relayTokens.set(token, { rootUrl: u.href, headers: safeHeaders(headers), resources: new Map(), title, createdAt: Date.now() });
  if (relayTokens.size > 100) {
    const oldest = [...relayTokens.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt).slice(0, relayTokens.size - 100);
    for (const [key] of oldest) relayTokens.delete(key);
  }
  return token;
}
function safeHeaders(input) {
  const out = {};
  for (const [key, value] of Object.entries(input || {})) {
    if (!/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(key)) continue;
    if (/^(host|connection|content-length|transfer-encoding|proxy-authorization)$/i.test(key)) continue;
    const str = String(value);
    if (str.length <= 4096 && !/[\r\n]/.test(str)) out[key] = str;
  }
  return out;
}
function relayAddress(req, token, pathName = 'root') {
  const host = String(req.headers.host || '');
  const name = host.split(':')[0].toLowerCase();
  const selected = !host || name === '127.0.0.1' || name === 'localhost' || name === '::1'
    ? `${getLanAddress().preferred}:${port}` : host;
  return `http://${selected}/relay/${token}/${pathName}`;
}
function registerResource(entry, url) {
  const id = crypto.randomBytes(9).toString('base64url');
  entry.resources.set(id, safeRemoteUrl(url).href);
  return id;
}
function rewritePlaylist(body, token, entry, sourceUrl) {
  const relayBase = `/relay/${token}/r/`;
  return body.split(/\r?\n/).map(line => {
    if (!line) return line;
    if (line.startsWith('#')) {
      return line.replace(/URI="([^"]+)"/g, (whole, uri) => {
        if (/^(skd:|data:|urn:)/i.test(uri)) return whole; // do not rewrite DRM/key-system URIs
        try { return `URI="${relayBase}${registerResource(entry, new URL(uri, sourceUrl).href)}"`; }
        catch { return whole; }
      });
    }
    try { return `${relayBase}${registerResource(entry, new URL(line.trim(), sourceUrl).href)}`; }
    catch { return line; }
  }).join('\n');
}
async function relayRequest(req, res, urlObj) {
  const [, , token, kind, resourceId] = urlObj.pathname.split('/');
  const entry = relayTokens.get(token);
  if (!entry) return text(res, 404, 'Relay session expired. Resolve the stream again.');
  let upstream;
  if (kind === 'root') upstream = entry.rootUrl;
  else if (kind === 'r' && entry.resources.has(resourceId)) upstream = entry.resources.get(resourceId);
  else return text(res, 404, 'Unknown relay resource.');
  upstream = safeRemoteUrl(upstream);
  const outbound = { ...entry.headers };
  if (req.headers.range) outbound.range = req.headers.range;
  if (req.headers['if-none-match']) outbound['if-none-match'] = req.headers['if-none-match'];
  let response;
  try {
    response = await fetch(upstream, { method: req.method === 'HEAD' ? 'HEAD' : 'GET', headers: outbound, redirect: 'follow', signal: AbortSignal.timeout(20000) });
  } catch (error) {
    return text(res, 502, `Upstream stream request failed: ${error.message}`);
  }
  const finalUrl = safeRemoteUrl(response.url || upstream.href);
  if (!response.ok) {
    const detail = (await response.text().catch(() => '')).slice(0, 200);
    return text(res, response.status === 403 ? 502 : response.status, `Upstream returned HTTP ${response.status}${detail ? `: ${detail}` : ''}`);
  }
  const contentType = response.headers.get('content-type') || '';
  const pathLike = finalUrl.pathname.toLowerCase();
  const isPlaylist = pathLike.includes('.m3u8') || /mpegurl/i.test(contentType);
  let bytes;
  if (req.method === 'HEAD') {
    res.writeHead(response.status, { 'content-type': contentType || 'application/octet-stream', 'cache-control': 'no-store' });
    return res.end();
  }
  const max = isPlaylist ? 8 * 1024 * 1024 : 48 * 1024 * 1024;
  const ab = await response.arrayBuffer();
  bytes = Buffer.from(ab);
  if (bytes.length > max) return text(res, 413, 'Upstream object exceeded the relay size limit.');
  const looksLikePlaylist = isPlaylist || bytes.subarray(0, 7).toString('utf8') === '#EXTM3U';
  if (looksLikePlaylist) {
    const rewritten = Buffer.from(rewritePlaylist(bytes.toString('utf8'), token, entry, finalUrl.href));
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl; charset=utf-8', 'content-length': rewritten.length, 'cache-control': 'no-store', 'access-control-allow-origin': '*' });
    return res.end(rewritten);
  }
  const headers = {
    'content-type': contentType || 'application/octet-stream',
    'content-length': bytes.length,
    'cache-control': 'no-store',
    'access-control-allow-origin': '*'
  };
  const range = response.headers.get('content-range');
  const accepts = response.headers.get('accept-ranges');
  if (range) headers['content-range'] = range;
  if (accepts) headers['accept-ranges'] = accepts;
  res.writeHead(response.status, headers);
  res.end(bytes);
}
function getLanAddress() {
  const all = Object.values(os.networkInterfaces()).flat().filter(v => v && v.family === 'IPv4' && !v.internal).map(v => v.address);
  const preference = all.find(a => /^192\.168\./.test(a)) || all.find(a => /^10\./.test(a)) || all.find(a => /^172\.(1[6-9]|2\d|3[01])\./.test(a)) || all[0];
  return { preferred: preference ?? '127.0.0.1', all };
}
function staticFile(req, res, pathname) {
  let requestPath;
  try { requestPath = decodeURIComponent(pathname === '/' ? '/index.html' : pathname); } catch { return text(res, 400, 'Bad path'); }
  const file = path.resolve(WEB, `.${requestPath}`);
  if (file !== WEB && !file.startsWith(`${WEB}${path.sep}`)) return text(res, 403, 'Forbidden');
  let stat;
  try { stat = fs.statSync(file); } catch { return text(res, 404, 'Not found'); }
  if (!stat.isFile()) return text(res, 404, 'Not found');
  const types = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.json':'application/json; charset=utf-8', '.m3u':'audio/x-mpegurl; charset=utf-8' };
  res.writeHead(200, { 'content-type': types[path.extname(file).toLowerCase()] || 'application/octet-stream', 'content-length': stat.size, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-allow-headers': 'content-type, range' }); return res.end(); }
    if (url.pathname === '/api/health') return json(res, 200, { ok: true, app: 'RBTV+ PS5 Port', version: PORT_VERSION, network: getLanAddress(), relaySessions: relayTokens.size });
    if (url.pathname === '/api/config' && req.method === 'GET') {
      return json(res, 200, { ...config, deviceId, listenPort: port, apiHostsRequireUserReview: true, network: getLanAddress() });
    }
    if (url.pathname === '/api/config' && req.method === 'POST') {
      const input = JSON.parse(await readBody(req));
      saveConfig(input);
      api = new RbtvApi(config);
      return json(res, 200, { ok: true, config: { ...config, deviceId } });
    }
    if (url.pathname === '/api/connect') {
      const userInfo = await api.getUserInfo();
      const activation = await activationStatus().catch(error => ({ free: false, activated: false, error: error.message }));
      return json(res, 200, { ok: true, userInfo, activation, deviceId });
    }
    if (url.pathname === '/api/matches') {
      const sportType = Number(url.searchParams.get('sportType') || config.sportType || 1);
      const language = Number(url.searchParams.get('language') || config.language || 0);
      const result = await api.getLiveMatches({ sportType, language });
      const streamsByMatch = new Map();
      for (const stream of result.streams) {
        const key = String(stream.matchId);
        if (!streamsByMatch.has(key)) streamsByMatch.set(key, []);
        streamsByMatch.get(key).push({ id: stream.id, name: stream.fullName || stream.name || `Stream ${stream.id}`, status: stream.status, recommended: stream.recommended, priority: stream.priority, siteType: stream.siteType });
      }
      return json(res, 200, { ...result, sportType, sportLabel: sportLabel(sportType), matches: result.matches.map(m => ({ ...m, streams: streamsByMatch.get(String(m.id)) || [] })) });
    }
    const detail = url.pathname.match(/^\/api\/match\/(\d+)$/);
    if (detail) {
      const matchId = Number(detail[1]);
      const sportType = Number(url.searchParams.get('sportType') || config.sportType || 1);
      const language = Number(url.searchParams.get('language') || config.language || 0);
      const result = await api.getMatchDetail({ matchId, sportType, language });
      return json(res, 200, result);
    }
    if (url.pathname === '/api/user-info') return json(res, 200, await api.getUserInfo());
    if (url.pathname === '/api/activation/policy') {
      const info = await api.getUserInfo().catch(() => ({ continent: '', country: '' }));
      const result = await api.getActivationPolicy({ continent: info.continent, country: info.country });
      return json(res, 200, { free: false, activated: false, code: result.envelope.code, message: result.envelope.message, dataBytes: result.activation.length });
    }
    if (url.pathname === '/api/activation/status') return json(res, 200, await activationStatus());
    if (url.pathname === '/api/activation/verify' && req.method === 'POST') {
      const body = JSON.parse(await readBody(req));
      const code = String(body.activationCode || '').trim();
      if (!code) return json(res, 400, { error: 'Enter the activation code issued by the service provider.' });
      const result = await api.verifyActivation(deviceId, code);
      return json(res, 200, { ok: true, activation: statFields(result.envelope), message: result.envelope.message });
    }
    if (url.pathname === '/api/resolve' && req.method === 'POST') {
      const request = JSON.parse(await readBody(req));
      const activation = await requireActivation();
      const resolved = await api.resolveStream({
        matchId: Number(request.matchId), sportType: Number(request.sportType),
        streamId: Number(request.streamId), siteType: Number(request.siteType), withOriginal: true
      });
      const stream = resolved.stream;
      const token = createRelay(stream.url, stream.headers, request.title || stream.fullName || stream.name);
      lastResolved = {
        title: String(request.title || stream.fullName || stream.name || 'RBTV+ stream').slice(0, 180),
        relayUrl: relayAddress(req, token), token, streamId: stream.id, matchId: Number(request.matchId), sportType: Number(request.sportType),
        resolvedAt: new Date().toISOString(), activation
      };
      return json(res, 200, { title: lastResolved.title, relayUrl: lastResolved.relayUrl, streamName: stream.fullName || stream.name, streamId: stream.id, headerCount: Object.keys(stream.headers || {}).length, note: 'Relay supports ordinary HTTP(S) HLS and carries stream headers; P2P/CSL injection and DRM systems are not bypassed.' });
    }
    if (url.pathname === '/api/current.m3u') {
      if (!lastResolved) return text(res, 409, '#EXTM3U\n# No stream selected yet. Select a match and resolve a stream in RBTV+ first.\n', 'audio/x-mpegurl; charset=utf-8');
      const title = lastResolved.title.replace(/[\r\n,]/g, ' ').slice(0, 150);
      return text(res, 200, `#EXTM3U\n#EXTINF:-1,${title}\n${lastResolved.relayUrl}\n`, 'audio/x-mpegurl; charset=utf-8');
    }
    if (url.pathname.startsWith('/relay/')) return await relayRequest(req, res, url);
    if (req.method === 'GET' || req.method === 'HEAD') return staticFile(req, res, url.pathname);
    return text(res, 404, 'Not found');
  } catch (error) {
    const status = error.statusCode || 502;
    json(res, status, { error: error.message || 'Request failed', code: error.code || 'PORT_ERROR', activation: error.activation ?? undefined });
  }
});

server.listen(port, '0.0.0.0', () => {
  const net = getLanAddress();
  console.log(`\nRBTV+ PS5 Port ${PORT_VERSION}`);
  console.log(`Web UI: http://127.0.0.1:${port}`);
  console.log(`Preferred LAN: http://${net.preferred}:${port}`);
  console.log(`Other IPv4: ${net.all.map(ip => `http://${ip}:${port}`).join('  ') || '(none detected)'}`);
  console.log('API calls only start when you press Connect / Load live matches.');
  console.log('Keep it on a trusted LAN; do not port-forward. Ctrl+C to stop.\n');
});
