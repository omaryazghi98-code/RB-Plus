$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host 'Node.js 20+ is required. Install it from https://nodejs.org/' -ForegroundColor Red
  exit 1
}
$env:PORT = '4173'
Write-Host ''
Write-Host 'RBTV+ PS5 Port 0.3.0' -ForegroundColor Cyan
Write-Host 'This runs a real API adapter and local HLS relay; it is not the old mock Playback Lab.' -ForegroundColor Gray
Write-Host 'Press Ctrl+C to stop. Do not port-forward this server.' -ForegroundColor Yellow
node .\server.mjs
