import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseFields, parsePBResponse, parseSignatureResponse, parseLiveResponse,
  parseMatchDetailResponse, parseStreamResponse, parseActivationEnvelope
} from '../lib/protobuf.mjs';

function vi(n) {
  let x = BigInt(n); const out = [];
  while (x > 0x7fn) { out.push(Number(x & 0x7fn) | 0x80); x >>= 7n; }
  out.push(Number(x)); return Buffer.from(out);
}
function fvar(n, value) { return Buffer.concat([vi((n << 3) | 0), vi(value)]); }
function fbytes(n, value) { const b = Buffer.isBuffer(value) ? value : Buffer.from(value); return Buffer.concat([vi((n << 3) | 2), vi(b.length), b]); }
function fstr(n, value) { return fbytes(n, Buffer.from(value)); }
function mapEntry(k, v, keyType = 'string', valueType = 'string') {
  const key = keyType === 'number' ? fvar(1, k) : fstr(1, String(k));
  let val;
  if (valueType === 'number' || valueType === 'bool') val = fvar(2, v);
  else val = fstr(2, String(v));
  return Buffer.concat([key, val]);
}
function env(data, extras = []) { return Buffer.concat([fvar(2, 0), fstr(3, ''), ...extras, fbytes(10, data)]); }

test('generic protobuf parser recognizes varint and length-delimited fields', () => {
  const f = parseFields(Buffer.concat([fvar(2, 323), fstr(3, 'RBTV')]));
  assert.equal(Number(f.find(x => x.number === 2).value), 323);
  assert.equal(f.find(x => x.number === 3).value.toString(), 'RBTV');
});

test('PBResponse and bootstrap signature map decode', () => {
  const body = fbytes(1, mapEntry(100, 'v3.0'));
  const response = parsePBResponse(env(body));
  assert.equal(response.code, 0);
  assert.equal(parseSignatureResponse(response.data)['100'], 'v3.0');
});

test('live catalogue decodes match, team, league and stream rows', () => {
  const team = Buffer.concat([fvar(1, 55), fbytes(3, mapEntry(0, 'Home FC', 'number')), fstr(4, 'https://logos.example/home.png')]);
  const away = Buffer.concat([fvar(1, 56), fbytes(3, mapEntry(0, 'Away FC', 'number'))]);
  const league = Buffer.concat([fvar(1, 8), fvar(2, 1), fbytes(3, mapEntry(0, 'Test League', 'number'))]);
  const match = Buffer.concat([fvar(1, 456), fvar(2, 1), fvar(3, 1700000000), fvar(4, 1), fbytes(10, league), fstr(19, 'fixture'), fbytes(20, team), fbytes(21, away), fvar(22, 2), fvar(23, 1), fvar(80, 1)]);
  const stream = Buffer.concat([fvar(1, 999), fvar(2, 1), fstr(3, 'Main feed'), fstr(4, 'https://cdn.example/live.m3u8'), fvar(7, 1), fvar(8, 5), fvar(9, 2), fbytes(20, mapEntry('Referer', 'https://www.example.org')) , fvar(50,456)]);
  const live = Buffer.concat([fbytes(1, match), fbytes(2, stream)]);
  const result = parseLiveResponse(live, 0);
  assert.equal(result.matches.length, 1);
  assert.equal(result.matches[0].home.name, 'Home FC');
  assert.equal(result.matches[0].away.name, 'Away FC');
  assert.equal(result.matches[0].league.name, 'Test League');
  assert.equal(result.matches[0].homeScore, 2);
  assert.equal(result.streams[0].url, 'https://cdn.example/live.m3u8');
  assert.equal(result.streams[0].headers.Referer, 'https://www.example.org');
});

test('match detail and single stream response are decoded', () => {
  const match = Buffer.concat([fvar(1, 5), fvar(2, 1), fstr(19, 'Derby')]);
  const stream = Buffer.concat([fvar(1, 7), fstr(3, 'HD'), fstr(4, 'https://media.example/a.m3u8')]);
  assert.equal(parseMatchDetailResponse(Buffer.concat([fbytes(1, match), fbytes(2, stream)])).match.name, 'Derby');
  assert.equal(parseStreamResponse(Buffer.concat([fbytes(2, stream)])).id, 7);
});

test('activation envelope obeys free/activated flags and magic offset', () => {
  const activation = Buffer.concat([fvar(1, 1), fvar(2, 0), fstr(3, 'DEMO')]);
  const free = parseActivationEnvelope({ data: activation, magic: Buffer.from('') });
  assert.equal(free.free, true);
  assert.equal(free.activated, false);
  const magicParam = Buffer.concat([fvar(1, 1), fvar(10, 2)]);
  const magic = Buffer.concat([fvar(1, 1), fbytes(2, magicParam)]).toString('base64');
  const paddedData = Buffer.concat([Buffer.from([9,9]), activation]);
  const decoded = parseActivationEnvelope({ data: paddedData, magic: Buffer.from(magic) });
  assert.equal(decoded.protocolVersion, 1);
  assert.equal(decoded.activationCode, 'DEMO');
});
