import test from 'node:test';
import assert from 'node:assert/strict';
import { RbtvApi } from '../lib/rbtv-api.mjs';

function vi(n) { let x=BigInt(n), out=[]; while(x>127n){out.push(Number(x&127n)|128);x>>=7n;}out.push(Number(x));return Buffer.from(out); }
function v(n,x){return Buffer.concat([vi((n<<3)|0),vi(x)]);}
function b(n,x){x=Buffer.isBuffer(x)?x:Buffer.from(x);return Buffer.concat([vi((n<<3)|2),vi(x.length),x]);}
function s(n,x){return b(n,Buffer.from(x));}
function mapEntry(k,value){return Buffer.concat([v(1,k),s(2,value)]);}
function response(data, headers={}) { return new Response(Buffer.concat([v(2,0), b(10,data)]), {status:200,headers}); }
const config = { dataApi:'https://data.example/', liveApi:'https://live.example/', webOrigin:'https://www.example.org', digit:'snd',language:0,sportType:1,userAgent:'test', networkTimeoutMs:1000,maxResponseBytes:100000 };

test('live request uses bootstrap version and signed path, then decodes protobuf catalogue', async () => {
  const calls=[];
  const mockFetch=async input=>{
    const u=new URL(input); calls.push(u);
    if(u.pathname==='/api/common/bs') return response(b(1,mapEntry(100,'rev7')));
    if(u.pathname==='/sfver'+(await import('node:crypto')).default.createHash('md5').update('language=0&sportType=1&stream=true').digest('hex').slice(0,6)+'rev7/api/match/live') {
      const nestedMatch=Buffer.concat([v(1,44),v(2,1),s(19,'Test')]);
      return response(b(1,nestedMatch), {date:'Fri, 09 Oct 2026 08:00:00 GMT'});
    }
    throw new Error('Unexpected URL: '+u.href);
  };
  const api=new RbtvApi(config,mockFetch);
  const live=await api.getLiveMatches({sportType:1,language:0});
  assert.equal(live.matches[0].id,44);
  assert.equal(calls[0].pathname,'/api/common/bs');
  assert.equal(calls[0].searchParams.get('code'),'100');
  assert.equal(calls[1].searchParams.get('stream'),'true');
  assert.equal(calls[1].searchParams.get('sportType'),'1');
});

test('API adapter rejects insecure service endpoints', async () => {
  const api = new RbtvApi({...config,dataApi:'http://data.example'});
  await assert.rejects(() => api.getLiveMatches({sportType:1,language:0}), /must use HTTPS/);
});
