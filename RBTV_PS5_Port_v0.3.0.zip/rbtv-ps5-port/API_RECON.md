# RBTV+ APK service map (safe, static-analysis summary)

Source examined: the user-provided `com.rblive.tv-release-323-v3.0.323.apk`. No APK code was executed and no service host was contacted while building this project.

## Confirmed request flow

1. Bootstrap body/signature map: `GET /api/common/bs` with `code=100`, `sportType=<n>`, `stream=true` for a live catalogue. The response's protobuf `PBBodySignatureResp.kv[100]` supplies the version fragment.
2. Live catalogue: `GET /sfver<first-6-MD5><version>/api/match/live?language=<n>&sportType=<n>&stream=true`, where the MD5 input is `language=<n>&sportType=<n>&stream=true`.
3. Match detail bootstrap: `GET /api/common/bs` with codes `102,103,104,105,106,107`, `sportType=<n>` and `matchId=<id>`.
4. Match detail: `GET /sfver<first-6-MD5><version>/api/match/detail?matchId=<id>&language=<n>&sportType=<n>&stream=true`, MD5 input `matchId=<id>&language=<n>&sportType=<n>&stream=true`.
5. Stream resolution: `GET /api/stream/detail` with `matchId`, `sportType`, `streamId`, `siteType`, `continent`, `country`, `digit`, and `withOriginal=true`.
6. Activation API: `GET /api/activation/policy`, `GET /api/activation/status?deviceId=...`, `POST /api/activation/verify` with the app's JSON envelope. Activation response bytes are protobuf and may be offset according to the base64-encoded `PBMagic` envelope.

## Wire shapes implemented

- `PBResponse`: request token #1, code #2, message #3, magic #4, data #10.
- `PBBodySignatureResp`: key/value map #1.
- `PBMatchLiveResp`: repeated match #1, repeated stream #2.
- `PBMatchDetailResp`: match #1, repeated stream #2.
- `PBStreamResp`: stream #2.
- `PBDataMatch`: match ID #1, sport #2, date #3, status #4, league #10, name #19, home #20, away #21, scores #22/#23, hot #80.
- `PBDataStream`: stream ID #1, sport #2, name #3, URL #4, status #5, available type #6, recommended #7, priority #8, site type #9, name #10, CDN type #11, backup domains #12, headers map #20, match ID #50.

## Known gap: original stream middleware

The APK also downloads dynamic remote configuration and uses `PPNetInterceptor`, a P2P/HLS injection manager, CDN “smart link” processing and WebRTC/data-channel code. Those systems are not reconstructed here. The relay supports standard HTTP(S) HLS playlist/segment/key references and the stream's returned headers; it does not bypass DRM, manufacture activation or implement proprietary P2P/CDN rewriting. Some feeds may therefore not work until this middleware is ported or a direct stream is available.

## Embedded endpoints

The default data/live/logo/origin values in `config.json` were extracted from the APK's bundled environment configuration. They are unusual third-party domains and could be stale, reassigned or untrusted. The app has an explicit user approval checkbox before the first network call, and the endpoints are editable in Settings. Treat a connection failure as a reason to reassess the endpoint, not to disable TLS or bypass activation.
